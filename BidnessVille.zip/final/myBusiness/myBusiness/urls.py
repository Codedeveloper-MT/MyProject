from django.contrib import admin
from django.urls import path, include
from myApp.views import login_view, index

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/', login_view, name='login'),
    path('', index, name='index'),  # Root URL points to index view
    path('', include('myApp.urls')),  # Include myApp's URL patterns
]
