from django.urls import path
from . import views  # Import your views

urlpatterns = [
    path('login/', views.login_view, name='login_view'),  # Define the login URL
    # Add other URL patterns here as needed
     path('signup/', views.sign_up, name='sign_up'),
]