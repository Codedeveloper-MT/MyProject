function handleLogin(event) {
    event.preventDefault(); // Prevent form submission
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // Simple validation example
    if (username === "user" && password === "pass") {
        document.getElementById('loginSuccess').textContent = "Login Successful!";
        document.getElementById('loginSuccess').style.display = 'block';
        document.getElementById('loginAlert').style.display = 'none'; // Hide error alert
    } else {
        document.getElementById('loginAlert').textContent = "Invalid username or password.";
        document.getElementById('loginAlert').style.display = 'block'; // Show error alert
        document.getElementById('loginSuccess').style.display = 'none'; // Hide success alert
    }
}

function handleSignup(event) {
    event.preventDefault(); // Prevent form submission
    const username = document.getElementById("signupUsername").value;
    const email = document.getElementById("signupEmail").value;
    const password = document.getElementById("signupPassword").value;

    // Simple validation example
    if (username && email && password) {
        document.getElementById('signupSuccess').textContent = "Sign-up Successful!";
        document.getElementById('signupSuccess').style.display = 'block'; // Show success alert
        document.getElementById('signupAlert').style.display = 'none'; // Hide error alert
        $('#signupModal').modal('hide'); // Hide the modal after submission
        setTimeout(() => {
            document.getElementById('signupSuccess').style.display = 'none'; // Hide success message after 3 seconds
        }, 3000);
    } else {
        document.getElementById('signupAlert').textContent = "Please fill out all fields.";
        document.getElementById('signupAlert').style.display = 'block'; // Show error alert
        document.getElementById('signupSuccess').style.display = 'none'; // Hide success alert
    }
}

function handleSignin() {
    // Implement your Forget Password functionality here
    alert("Forget Password functionality to be implemented.");
}